package com.basoft.todo;

public interface DataChangeObserver {
    void onTaskUpdated(int position);
}
