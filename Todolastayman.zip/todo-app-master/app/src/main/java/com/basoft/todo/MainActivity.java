package com.basoft.todo;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Notification;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.snackbar.Snackbar;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static com.basoft.todo.NotificationHelper.cancelNotification;

import static com.basoft.todo.NotificationHelper.notificationId;
import static com.basoft.todo.NotificationHelper.scheduleNotification;
import static com.basoft.todo.NotificationReceiver.mediaPlayer;
import static com.basoft.todo.WidgetUpdateService.startActionUpdateTasksListView;


public class MainActivity extends AppCompatActivity implements DataChangeObserver {
    static Calendar calendar = Calendar.getInstance();
    private static final Integer DEFAULT_DEADLINE_HOUR = calendar.get(Calendar.HOUR_OF_DAY), DEFAULT_DEADLINE_MINUTE = calendar.get(Calendar.MINUTE);

    private static final int DEFAULT_DEADLINE_YEAR = calendar.get(Calendar.YEAR);
    private static final int DEFAULT_DEADLINE_MONTH = calendar.get(Calendar.MONTH);
    private static final int DEFAULT_DEADLINE_DAY = calendar.get(Calendar.DAY_OF_MONTH);
    private EditText newTaskEditText;
    private Button newTaskSubmitButton, newTaskDeadlineDateButton, newTaskDeadlineTimeButton;
    private RecyclerView tasksRecyclerView;
    private Integer deadlineYear, deadlineMonth, deadlineDay, deadlineHour, deadlineMinute;
    private TaskAdapter taskAdapter;
    private TextView greetingTextView;
    private BootCompleteReceiver bootCompleteReceiver = new BootCompleteReceiver();
    public static final String SHARED_PREFERENCES_NAME = "ba_soft_todo";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


       // Toast.makeText(this, notificationId, Toast.LENGTH_SHORT).show();
   int a =   loadDataFromSavedPreferences();
       Toast.makeText(this,"prefrence of notficationid"+ String.valueOf(a), Toast.LENGTH_SHORT).show();
        findViews();

        newTaskDeadlineDateButton.setOnClickListener(deadlineDateSelectListener);
        newTaskDeadlineTimeButton.setOnClickListener(deadlineTimeSelectListener);
        newTaskSubmitButton.setOnClickListener(newTaskSubmitListener);

        setupGreeting();
        setupTasksRecyclerView();
    }

    private void setupGreeting() {
        Calendar today = Calendar.getInstance();
        Locale locale = Locale.getDefault();
        SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM, yyyy", locale);
        String formattedDate = formatter.format(today.getTime());
        greetingTextView.setText(String.format(
                "%s %s", getString(R.string.today_is), formattedDate
        ));
    }

    private int loadDataFromSavedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES_NAME, MODE_PRIVATE);

        return NotificationHelper.notificationId = sharedPreferences.getInt(NotificationReceiver.NOTIFICATION_ID, 0) + 1;
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_BOOT_COMPLETED);
        intentFilter.addAction(Intent.ACTION_LOCKED_BOOT_COMPLETED);
        this.registerReceiver(bootCompleteReceiver, intentFilter);
       // Toast.makeText(this, "ONSTART", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        notifyDatasetChanged();
     //   Toast.makeText(this, "ONRESUME", Toast.LENGTH_SHORT).show();

    }


    @Override
    protected void onStop() {
        super.onStop();
        this.unregisterReceiver(bootCompleteReceiver);
       // Toast.makeText(this, "ONSTOP", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
      //  Toast.makeText(this, "ONDESTROY", Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onPause() {
        super.onPause();
      //  Toast.makeText(this, "ONPAUSE", Toast.LENGTH_SHORT).show();
        DataManager dataManager = DataManager.getInstance();
        dataManager.saveTasksToLocalStorage(MainActivity.this);
        saveDataToSharedPreferences();
        startActionUpdateTasksListView(MainActivity.this);
    }

    private void saveDataToSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(NotificationReceiver.NOTIFICATION_ID, NotificationHelper.notificationId);
        editor.apply();
    }

    private void setupTasksRecyclerView() {
        DataManager dataManager = DataManager.getInstance();
dataManager.loadTasksFromLocalStorage(MainActivity.this);
        tasksRecyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        taskAdapter = new TaskAdapter(dataManager.getTasks(), MainActivity.this);
        tasksRecyclerView.setAdapter(taskAdapter);
    }

    private void findViews() {
        newTaskEditText = findViewById(R.id.new_task_edittext);
        newTaskSubmitButton = findViewById(R.id.new_task_button);
        newTaskDeadlineDateButton = findViewById(R.id.new_task_deadline_date);
        newTaskDeadlineTimeButton = findViewById(R.id.new_task_deadline_time);
        tasksRecyclerView = findViewById(R.id.tasks_recycler_view);
        greetingTextView = findViewById(R.id.greeting);
    }

    private final View.OnClickListener newTaskSubmitListener = new View.OnClickListener() {
        @SuppressLint("NotifyDataSetChanged")
        @Override
        public void onClick(View v) {
            String newTaskTitle = newTaskEditText.getText().toString().trim();


            if (newTaskTitle.isEmpty()) {

                                DataManager dataManager1 =DataManager.getInstance();
                           dataManager1.getTasks().get(TaskAdapter.position).cancelNotification(getApplicationContext());
                         //   NotificationHelper .cancelNotification(getApplicationContext(),NotificationHelper. notificationId);
            //  mediaPlayer.stop();

                //Toast.makeText(MainActivity.this, "EMPTYTSOAND CANCELNTFY"+  String.valueOf(TaskAdapter.position), Toast.LENGTH_SHORT).show();
                resetViews();


                return;
            }


            TaskTodo newTask = new TaskTodo(newTaskTitle);
            Calendar deadline = Calendar.getInstance();

            Date date1 = deadline.getTime();
           Toast.makeText(getApplicationContext(),  date1.toString()+deadlineHour, Toast.LENGTH_SHORT).show();
            boolean haveDeadline = deadlineYear != null && deadlineHour != null;


            if (haveDeadline) {
                deadline.set(Calendar.YEAR, deadlineYear);
                deadline.set(Calendar.MONTH, deadlineMonth);
                deadline.set(Calendar.DAY_OF_MONTH, deadlineDay);
                deadline.set(Calendar.HOUR_OF_DAY, deadlineHour);
                deadline.set(Calendar.MINUTE, deadlineMinute);
                deadline.set(Calendar.SECOND, 0);
                Date date = deadline.getTime();
               // Toast.makeText(getApplicationContext(),  "AYMANDATE"+ date.toString()+deadlineHour, Toast.LENGTH_SHORT).show();
                newTask = new TaskTodo(newTaskTitle, deadline);
                newTask.scheduleNotification(MainActivity.this);




            }

            DataManager dataManager = DataManager.getInstance();
            dataManager.addTask(newTask);
          dataManager. saveTasksToLocalStorage(getApplicationContext());
           // dataManager.updateTask(getApplicationContext(), taskAdapter.position, newTask);
           // taskAdapter.notifyDataSetChanged();
            notifyDatasetChanged();
            Toast.makeText(MainActivity.this, "saveddataandupdate", Toast.LENGTH_SHORT).show();
            resetViews();
        }
    };

    private void resetViews() {
        newTaskEditText.setText("");
        deadlineYear = deadlineMonth = deadlineDay = deadlineHour = deadlineMinute = null;
        newTaskDeadlineTimeButton.setText(R.string.select_time);
        newTaskDeadlineDateButton.setText(R.string.select_date);
    }

    private final View.OnClickListener deadlineDateSelectListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            OnDateSetListener onDateSetListener = new OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    setDeadlineDate(year, monthOfYear, dayOfMonth);
                    if (deadlineHour == null || deadlineMinute == null)
                        setDeadlineTime(DEFAULT_DEADLINE_HOUR, DEFAULT_DEADLINE_MINUTE);
                }
            };

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    MainActivity.this, onDateSetListener,
                    DEFAULT_DEADLINE_YEAR, DEFAULT_DEADLINE_MONTH, DEFAULT_DEADLINE_DAY
            );

            datePickerDialog.show();
        }
    };

    @SuppressLint("DefaultLocale")
    private void setDeadlineDate(int year, int monthOfYear, int dayOfMonth) {
        this.deadlineYear = year;
        this.deadlineMonth = monthOfYear;
        this.deadlineDay = dayOfMonth;
        newTaskDeadlineDateButton.setText(
                String.format("%02d/%02d/%04d", dayOfMonth, monthOfYear + 1, year)
        );
    }

    private final View.OnClickListener deadlineTimeSelectListener = new View.OnClickListener() {
       @Override
        public void onClick(View v) {

            OnTimeSetListener onTimeSetListener;
            onTimeSetListener = new OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    MainActivity.this.setDeadlineTime(hourOfDay, minute);
                    Toast.makeText(MainActivity.this, String.valueOf(hourOfDay), Toast.LENGTH_SHORT).show();
                    if (deadlineYear == null || deadlineMonth == null || deadlineDay == null)
                        MainActivity.this.setDeadlineDate(DEFAULT_DEADLINE_YEAR, DEFAULT_DEADLINE_MONTH, DEFAULT_DEADLINE_DAY);
                }
            };

            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    MainActivity.this, onTimeSetListener,
                    DEFAULT_DEADLINE_HOUR, DEFAULT_DEADLINE_MINUTE, false
            );

           timePickerDialog.show();
        }
    };

    @SuppressLint("DefaultLocale")
    private void setDeadlineTime(int hourOfDay, int minute) {
        this.deadlineHour = hourOfDay;
        this.deadlineMinute = minute;
        updateTime(hourOfDay,minute);
       // newTaskDeadlineTimeButton.setText(String.format("%02d:%02d", hourOfDay, minute));
    }

    public void notifyDatasetChanged() {
        tasksRecyclerView.post(new Runnable() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void run() {
                taskAdapter.notifyDataSetChanged();
            }


        });
       // Toast.makeText(this, "notifyDatasetChanged", Toast.LENGTH_SHORT).show();
    }

    public void notifyItemMoved(int fromPosition, int toPosition) {

        tasksRecyclerView.post(new Runnable() {
            @Override
            public void run() {
                taskAdapter.notifyItemMoved(fromPosition, toPosition);
            }


        });
        DataManager dataManager = DataManager.getInstance();
        dataManager.saveTasksToLocalStorage(getApplicationContext());
//Toast.makeText(this, "MOVEDITEM", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onTaskUpdated(int position) {
        tasksRecyclerView.post(new Runnable() {
            @Override
            public void run() {
                taskAdapter.notifyItemChanged(position);
            }
        });
        Toast.makeText(this, "NOTIFYITEMCHANG", Toast.LENGTH_SHORT).show();
    }
    private void updateTime(int hours, int mins) {

        String timeSet = "";
        if (hours > 12) {
            hours -= 12;
            timeSet = "PM";
        } else if (hours == 0) {
            hours += 12;
            timeSet = "AM";
        } else if (hours == 12)
            timeSet = "PM";
        else
            timeSet = "AM";


        String minutes = "";
        if (mins < 10)
            minutes = "0" + mins;
        else
            minutes = String.valueOf(mins);

        // Append in a StringBuilder
        String aTime = new StringBuilder().append(hours).append(':')
                .append(minutes).append(" ").append(timeSet).toString();

        newTaskDeadlineTimeButton.setText(aTime);


    }
}
