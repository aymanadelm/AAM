package com.basoft.todo;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class DataManager {
    private static final String TASKS_FILENAME = "tasks.dat";
    private static ArrayList<TaskTodo> tasks;
    private static DataManager singleInstance;
    private static DataChangeObserver observer;
public int position;
    public static DataManager getInstance() {
        return getInstance(null);
    }

    public static DataManager getInstance(DataChangeObserver dataChangeObserver) {
        if (singleInstance == null)
            singleInstance = new DataManager();
        if (dataChangeObserver != null)
            observer = dataChangeObserver;
        return singleInstance;
    }

    private DataManager() {
        // Do nothing
    }

    public ArrayList<TaskTodo> getTasks() {
        return tasks;
    }

    /** @noinspection unchecked*/
    public void loadTasksFromLocalStorage(Context context) {
        try {
            FileInputStream fileInputStream = context.openFileInput(TASKS_FILENAME);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            tasks = (ArrayList<TaskTodo>) objectInputStream.readObject();
            Toast.makeText(context, "LOADDATA"+tasks.toString(), Toast.LENGTH_SHORT).show();


        } catch (IOException | ClassNotFoundException e) {
            Log.d("Load task error:", e.toString());
            tasks = new ArrayList<>();
        }
    }

    public void saveTasksToLocalStorage(Context context) {
        try {
            FileOutputStream fileOutputStream = context.openFileOutput(TASKS_FILENAME, Context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(tasks);
         //  Toast.makeText(context,"aaaaayman" +tasks.toString(), Toast.LENGTH_SHORT).show();
            objectOutputStream.close();

        } catch (IOException e) {
            Log.d("Save tasks error:", e.toString());

        }
    }

    public void addTask(TaskTodo newTask) {
        tasks.add(newTask);
        moveTaskToCorrectPosition(tasks.size() - 1);
    }

    public int moveTaskToCorrectPosition(int position) {
        if (position >= tasks.size()) {
            return -1;
        }
        TaskTodo task = tasks.remove(position);
        int correctPosition = 0;
        if (!task.isDone()) {
            int end = 0;
            while (end < tasks.size() && !tasks.get(end).isDone()) {
                end++;
            }
            int index = 0;
            if (index >= end) {
            } else {
                do {
                    TaskTodo.TaskTodoComparator comparator = new TaskTodo.TaskTodoComparator();
                    if (comparator.compare(task, tasks.get(index)) <= 0) {
                        break;
                    }
                    index++;
                } while (index < end);
            }
            correctPosition = index;
        } else {
            int index = 0;
            while (index < tasks.size() && !tasks.get(index).isDone()) {
                index++;
            }
            // Now tasks[index] is done or index == n (which means there is no done task in tasks)
            while (index < tasks.size()) {
                TaskTodo.TaskTodoComparator comparator = new TaskTodo.TaskTodoComparator();
                if (comparator.compare(task, tasks.get(index)) > 0) {
                    index++;
                } else {
                    break;
                }
            }
            correctPosition = index;
        }
        tasks.add(correctPosition, task);
        return correctPosition;
    }

    public int setTaskDone(int position, boolean isDone) {
        if (position >= tasks.size()) return -1;
        tasks.get(position).setDone(isDone);
        return moveTaskToCorrectPosition(position);
    }

    public void deleteTask(int position,Context context) {
        if (position >= tasks.size()) return;
        tasks.remove(position);
        saveTasksToLocalStorage(context);



    }

    public TaskTodo getTask(int position) {
        if (position >= tasks.size()) return null;
        return tasks.get(position);

    }

    public boolean loadedTasks() {
        return tasks != null;
    }

    public void updateTask(Context context, int position, TaskTodo task) {
        tasks.get(position)
                .setTitle(task.getTitle())
                .setDeadline(task.getDeadline())
          .cancelNotification(context)
                .scheduleNotification(context);
        if (observer != null) observer.onTaskUpdated(position);
    }

    public ArrayList<TaskTodo> getUndoneTasks() {
        ArrayList<TaskTodo> undoneTasks = new ArrayList<>();
        for (TaskTodo task : tasks) {
            if (task.isNotDone()) undoneTasks.add(task.clone());
        }
        return undoneTasks;
    }
}
