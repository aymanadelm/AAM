package com.example.myaymanntodolistfinalll;



import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TaskDatabase db;
    private TaskAdapter adapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.DialogTheme);

        db = TaskDatabase.getDatabase(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize adapter with an empty list
        adapter = new TaskAdapter(this, new ArrayList<>());
        recyclerView.setAdapter(adapter);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddTaskDialog();
            }
        });

        loadTasks();
    }

    private void showAddTaskDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this, R.style.Theme_TodoSimple_Dialog);
        View view = getLayoutInflater().inflate(R.layout.dailog_add_task, null);
        EditText taskTitle = view.findViewById(R.id.taskTitle);
        Button addTask = view.findViewById(R.id.addTask);

        builder.setView(view);
        AlertDialog dialog = builder.create();

        addTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = taskTitle.getText().toString();
                if (!title.isEmpty()) {
                } else {
                    Toast.makeText(MainActivity.this, "EMPTY", Toast.LENGTH_SHORT).show();
                }
                Task task = new Task(title);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        db.taskDao().insertTask(task);
                    }
                }).start();
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void loadTasks() {
        // Room returns LiveData which automatically runs on a background thread
        // and notifies the observer on the main thread.
        db.taskDao().getAllTasks().observe(this, new Observer<List<Task>>() {
            @Override
            public void onChanged(List<Task> tasks) {
                adapter.setTaskList(tasks);
            }
        });
    }
}
