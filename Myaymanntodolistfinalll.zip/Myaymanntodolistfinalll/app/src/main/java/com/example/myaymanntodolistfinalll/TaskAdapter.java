package com.example.myaymanntodolistfinalll;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.ViewHolder> {
    private List<Task> taskList;
    private Context context;

    public TaskAdapter(Context context, List<Task> taskList) {
        this.context = context;
        this.taskList = taskList;
    }

    public void setTaskList(List<Task> taskList) {
        this.taskList = taskList;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.title.setText(task.getTitle());
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new AlertDialog.Builder(context, R.style.Theme_TodoSimple_Dialog)
                        .setTitle("حذف المهمة")
                        .setMessage("هل أنت متأكد من حذف هذه المهمة؟")
                        .setPositiveButton("حذف", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                TaskDatabase.databaseWriteExecutor.execute(new Runnable() {
                                    @Override
                                    public void run() {
                                        TaskDatabase.getDatabase(context).taskDao().deleteTask(task);
                                    }
                                });
                            }
                        })
                        .setNegativeButton("إلغاء", null)
                        .show();
                return true;
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context, R.style.Theme_TodoSimple_Dialog);
                View view = LayoutInflater.from(context).inflate(R.layout.dailog_add_task, null);
                EditText taskTitle = view.findViewById(R.id.taskTitle);
                taskTitle.setText(task.getTitle());
                Button addTask = view.findViewById(R.id.addTask);
                addTask.setText("تحديث");

                builder.setView(view);
                AlertDialog dialog = builder.create();

                addTask.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String title = taskTitle.getText().toString();
                        if (!title.isEmpty()) {
                            task.setTitle(title);
                            TaskDatabase.databaseWriteExecutor.execute(new Runnable() {
                                @Override
                                public void run() {
                                    TaskDatabase.getDatabase(context).taskDao().updateTask(task);
                                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (dialog.isShowing()) {
                                                dialog.dismiss();
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    }
                });

                dialog.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return taskList != null ? taskList.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView title;

        public ViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
        }
    }
}
