package com.example.mynotefromaiii;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private List<Note> noteList = new ArrayList<> ();
    private OnNoteCheckChangedListener listener;

    public interface OnNoteCheckChangedListener {
        void onCheckChanged(Note note, boolean isChecked);
    }

    public void setOnNoteCheckChangedListener(OnNoteCheckChangedListener listener) {
        this.listener = listener;
    }

    public void setNoteList(List<Note> notes) {
        this.noteList = notes;
        notifyDataSetChanged();
    }

    public Note getNoteAt(int position) {
        return noteList.get(position);
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_note, parent, false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note note = noteList.get(position);
        holder.textViewTitle.setText(note.getTitle());
        holder.textViewDate.setText(note.getFormattedDate());
        holder.checkBoxDone.setChecked(note.isDone());

        holder.checkBoxDone.setOnCheckedChangeListener(null); // Important to reset listener

        holder.checkBoxDone.setChecked(note.isDone());
        holder.checkBoxDone.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (listener != null) {
                listener.onCheckChanged(note, isChecked);
            }
        });
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public static class NoteViewHolder extends RecyclerView.ViewHolder {
        TextView textViewTitle, textViewDate;
        CheckBox checkBoxDone;

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            checkBoxDone = itemView.findViewById(R.id.checkBoxDone);
        }
    }
}
