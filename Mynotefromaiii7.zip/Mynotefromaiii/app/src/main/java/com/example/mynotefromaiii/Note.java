package com.example.mynotefromaiii;


import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;


@Entity(tableName = "note_table")
public class Note {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @NonNull
    private String title;

    private boolean isDone;

    private long timestamp; // الوقت بالتاريخ لتسهيل الترتيب

    public Note(@NonNull String title, boolean isDone, long timestamp) {
        this.title = title;
        this.isDone = isDone;
        this.timestamp = timestamp;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) { this.id = id; }

    @NonNull
    public String getTitle() {
        return title;
    }

    public void setTitle(@NonNull String title) {
        this.title = title;
    }

    public boolean isDone() {
        return isDone;
    }

    public void setDone(boolean done) {
        isDone = done;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    // تنسيق التاريخ لعرضه في TextView
    public String getFormattedDate() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd MMM yyyy - HH:mm");
        return sdf.format(new java.util.Date(timestamp));
    }
}
