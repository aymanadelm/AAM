package com.example.mynotefromaiii;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class NoteViewModel extends AndroidViewModel {

    private NoteRepository repository;
    private LiveData<List<Note>> allNotes;

    public NoteViewModel(@NonNull Application application) {
        super(application);
        repository = new NoteRepository(application);
        allNotes = repository.getAllNotes();
    }
    public LiveData<List<Note>> getNotesSortedByDate() {
        return repository.getNotesSortedByDate();
    }

    public LiveData<List<Note>> getNotesSortedByDone() {
        return repository.getNotesSortedByDone();
    }


    public void insert(Note note) {
        repository.insert(note);
    }

    public void update(Note note) {
        repository.update(note);
    }

    public void delete(Note note) {
        repository.delete(note);
    }

    public void deleteAllNotes() {
        repository.deleteAllNotes();
    }

    public LiveData<List<Note>> getAllNotes() {
        return allNotes;
    }
    public LiveData<Integer> getCompletedCount() {
        return repository.getCompletedCount();
    }
    public LiveData<List<Note>> getCompletedNotes() {
        return repository.getCompletedNotes();
    }

    public LiveData<List<Note>> getUncompletedNotes() {
        return repository.getUncompletedNotes();
    }



}
