package com.example.mynotefromaiii;

import android.accessibilityservice.InputMethod;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private NoteViewModel noteViewModel;
    private NoteAdapter adapter;
    private EditText editTextNote;
    private TextView textViewCount;
    private boolean isReversed = false;
    private Spinner spinnerSort;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textViewCompleted = findViewById(R.id.textViewCompleted);
        Button buttonReverse = findViewById(R.id.buttonReverse);
        Button buttonReset = findViewById(R.id.buttonReset);

        editTextNote = findViewById(R.id.editTextNote);
        Button buttonSave = findViewById(R.id.buttonSave);
        textViewCount = findViewById(R.id.textViewCount);
        RecyclerView recyclerView = findViewById(R.id.recyclerViewNotes);

        adapter = new NoteAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged ();
        Spinner spinnerFilter = findViewById(R.id.spinnerFilter);
        spinnerSort = findViewById(R.id.spinnerSort);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        buttonReverse.setOnClickListener(view -> {
            isReversed = !isReversed;

            // هنا نستخدم النوع الحالي من الفلترة
            int selectedPosition = spinnerFilter.getSelectedItemPosition();

            if (selectedPosition == 0) { // All
                noteViewModel.getAllNotes().observe(this, notes -> {
                    List<Note> sorted = new ArrayList<>(notes);
                    if (isReversed) Collections.reverse(sorted);
                    adapter.setNoteList(sorted);
                    textViewCount.setText("Total notes: " + sorted.size());
                });
            } else if (selectedPosition == 1) { // Completed
                noteViewModel.getCompletedNotes().observe(this, notes -> {
                    List<Note> sorted = new ArrayList<> (notes);
                    if (isReversed) Collections.reverse(sorted);
                    adapter.setNoteList(sorted);
                    textViewCount.setText("Completed: " + sorted.size());
                });
            } else if (selectedPosition == 2) { // Not Completed
                noteViewModel.getUncompletedNotes().observe(this, notes -> {
                    List<Note> sorted = new ArrayList<>(notes);
                    if (isReversed) Collections.reverse(sorted);
                    adapter.setNoteList(sorted);
                    textViewCount.setText("Not completed: " + sorted.size());
                });
            }
        });

        spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    noteViewModel.getAllNotes().observe(MainActivity.this, notes -> {
                        adapter.setNoteList(notes);
                        textViewCount.setText("Total notes: " + notes.size());
                    });
                } else if (position == 1) {
                    noteViewModel.getCompletedNotes().observe(MainActivity.this, notes -> {
                        adapter.setNoteList(notes);
                        textViewCount.setText("Completed: " + notes.size());
                    });
                } else if (position == 2) {
                    noteViewModel.getUncompletedNotes().observe(MainActivity.this, notes -> {
                        adapter.setNoteList(notes);
                        textViewCount.setText("Not completed: " + notes.size());
                    });
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // ViewModel Setup
        noteViewModel = new ViewModelProvider(this).get(NoteViewModel.class);

        // Observe notes
        noteViewModel.getAllNotes().observe(this, notes -> {
            adapter.setNoteList(notes);
            textViewCount.setText("Total notes: " + notes.size());
        });

        buttonReset.setOnClickListener(view -> {
            spinnerFilter.setSelection(0); // All
            spinnerSort.setSelection(0);   // By Date

            // Trigger default observer manually
            noteViewModel.getAllNotes().observe(MainActivity.this, notes -> {
                adapter.setNoteList(notes);
                textViewCount.setText("Total notes: " + notes.size());
            });
        });

        // Save Button Click
        buttonSave.setOnClickListener(view -> {
            String noteText = editTextNote.getText().toString().trim();
            if (!noteText.isEmpty()) {
                Note newNote = new Note(noteText, false, new Date().getTime());
                noteViewModel.insert(newNote);
                editTextNote.setText("");
            } else {
                Toast.makeText(this, "Enter note text", Toast.LENGTH_SHORT).show();
            }
        });
        Button buttonDeleteAll = findViewById(R.id.buttonDeleteAll);
        buttonDeleteAll.setOnClickListener(view -> {
            noteViewModel.deleteAllNotes();
            Toast.makeText(MainActivity.this, "All notes deleted", Toast.LENGTH_SHORT).show();
        });


        // Checkbox change
        adapter.setOnNoteCheckChangedListener((note, isChecked) -> {
            note.setDone(isChecked);
            noteViewModel.update(note);
        });
        noteViewModel.getCompletedCount().observe(this, new Observer<Integer> () {
            @Override
            public void onChanged(Integer count) {
                textViewCompleted.setText ("Completed: " + count);
            }
        });


        // Swipe to delete
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {

            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false; // We don't want move
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                Note noteToDelete = adapter.getNoteAt(viewHolder.getAdapterPosition());
                noteViewModel.delete(noteToDelete);
                Toast.makeText(MainActivity.this, "Note deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);
        Spinner spinnerSort = findViewById(R.id.spinnerSort);

        spinnerSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    noteViewModel.getNotesSortedByDate().observe(MainActivity.this, notes -> {
                        adapter.setNoteList(notes);
                        textViewCount.setText("Total notes: " + notes.size());
                    });
                } else if (position == 1) {
                    noteViewModel.getNotesSortedByDone().observe(MainActivity.this, notes -> {
                        adapter.setNoteList(notes);
                        textViewCount.setText("Total notes: " + notes.size());
                    });
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }
}
