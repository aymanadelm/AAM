package com.example.mynotefromaiii;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Delete;
import androidx.room.Update;

import java.util.List;

@Dao
public interface NoteDao {

    @Insert
    void insert(Note note);

    @Update
    void update(Note note);

    @Delete
    void delete(Note note);

    @Query("DELETE FROM note_table")
    void deleteAllNotes();

    @Query("SELECT * FROM note_table ORDER BY timestamp DESC")
    LiveData<List<Note>> getAllNotes();
    @Query("SELECT * FROM note_table ORDER BY timestamp DESC")
    LiveData<List<Note>> getNotesSortedByDate();

    @Query("SELECT * FROM note_table ORDER BY isDone ASC, timestamp DESC")
    LiveData<List<Note>> getNotesSortedByDone();
    @Query("SELECT COUNT(*) FROM note_table WHERE isDone = 1")
    LiveData<Integer> getCompletedCount();
    @Query("SELECT * FROM note_table WHERE isDone = 1 ORDER BY timestamp DESC")
    LiveData<List<Note>> getCompletedNotes();

    @Query("SELECT * FROM note_table WHERE isDone = 0 ORDER BY timestamp DESC")
    LiveData<List<Note>> getUncompletedNotes();




}
